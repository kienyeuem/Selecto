/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      // Claude sẽ thêm màu, font tuỳ chỉnh vào đây khi bạn yêu cầu
    },
  },
  plugins: [],
}
