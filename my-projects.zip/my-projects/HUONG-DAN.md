# 🚀 HƯỚNG DẪN VIBE CODE VỚI CLAUDE

## Cấu trúc folder

```
my-projects/
├── public/            ← File tĩnh (ảnh, icon, favicon...)
├── src/
│   ├── components/    ← Các khối UI nhỏ tái sử dụng (Button, Card, Sidebar...)
│   ├── pages/         ← Mỗi trang một file (Home, Dashboard, Settings...)
│   ├── hooks/         ← Logic xử lý dùng lại (gọi API, quản lý state...)
│   ├── utils/         ← Hàm tiện ích (format ngày, tính toán...)
│   └── assets/        ← Ảnh, font, icon dùng trong code
├── package.json       ← Danh sách thư viện cần cài
├── tailwind.config.js ← Cấu hình màu sắc, font chữ
└── HUONG-DAN.md       ← File này!
```

## Cách nói chuyện với Claude để vibe code hiệu quả

### ✅ Nên nói thế này:
- "Tạo trang Dashboard có bảng hiển thị danh sách khách hàng"
- "Thêm nút xóa vào mỗi dòng trong bảng"
- "Đổi màu sidebar sang tối, thêm hiệu ứng hover"
- "Tạo component Card hiển thị thông tin sản phẩm"
- "Thêm chức năng lọc theo ngày vào bảng"

### ❌ Không cần nói:
- Tên thư viện cụ thể (Claude tự chọn)
- Cú pháp code (Claude tự viết)
- Cách cài đặt (Claude hướng dẫn)

## Mẹo vibe code

1. **Mô tả bằng hình ảnh**: "Mình muốn sidebar bên trái, nội dung chính bên phải"
2. **Sửa từng phần**: Đừng yêu cầu thay đổi quá nhiều cùng lúc
3. **Nói rõ cảm xúc**: "Trông chưa đẹp" → Claude sẽ cải thiện
4. **Gửi ảnh mẫu**: Nếu có UI mẫu, gửi ảnh để Claude tham khảo

## Tech stack đã chọn

| Công nghệ | Vai trò | Tại sao chọn? |
|-----------|---------|---------------|
| **React** | Xây giao diện | Component rõ ràng, dễ sửa từng phần |
| **Tailwind CSS** | Trang trí | Style nhanh bằng class, không cần viết CSS |
| **React Router** | Chuyển trang | Điều hướng giữa các trang mượt mà |
| **Lucide React** | Icon | Bộ icon đẹp, nhẹ, đa dạng |
| **Recharts** | Biểu đồ | Vẽ chart dễ dàng cho dashboard |

## Bắt đầu dự án mới

Nói với Claude: **"Tạo app [tên app] với trang [liệt kê trang]"**

Ví dụ: "Tạo app quản lý kho hàng với trang Dashboard, trang Sản phẩm, và trang Nhập hàng"
